<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='XMindProfile' timestamp='1546894557374'>
  <properties size='11'>
    <property name='org.eclipse.equinox.p2.cache' value='F:\blog\source\_posts\Intro-to-Python-Libs'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86,osgi.ws=win32,osgi.nl=en_HK'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='D:\BTTTT\xmind 8 update 8\XMind 8 Update 8'/>
    <property name='eclipse.touchpoint.launcherName' value='XMind'/>
    <property name='org.eclipse.equinox.p2.surrogate' value='true'/>
    <property name='org.eclipse.equinox.p2.cache.shared' value='E:\XMind 8 Update 8'/>
    <property name='org.eclipse.equinox.p2.configurationFolder' value='F:\blog\source\_posts\Intro-to-Python-Libs\configuration'/>
    <property name='org.eclipse.equinox.p2.launcherConfiguration' value='F:\blog\source\_posts\Intro-to-Python-Libs\configuration\eclipse.ini.ignored'/>
    <property name='org.eclipse.equinox.p2.cache.extensions' value='file:/E:/XMind%208%20Update%208/.eclipseextension|file:/E:/XMind%208%20Update%208/configuration/org.eclipse.osgi/718/data/listener_1925729951/'/>
  </properties>
  <units size='23'>
    <unit id='SharedProfile_XMindProfile' version='1.0.0.1545818442177' singleton='false' generation='2'>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Shared profile'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='SharedProfile_XMindProfile' version='1.0.0.1545818442177'/>
      </provides>
      <requires size='23'>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.share.localnetwork.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.share.biggerplate.nls.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.cathy.product.executable.win32.win32.x86&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.meggy.nls.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.share.general.nls.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;net.xmind.workbench.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;SharedProfile_XMindProfile&apos;, version(&apos;1.0.0.1545816213025&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.share.biggerplate.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.share.localnetwork.nls.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;net.xmind.workbench.nls.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.help.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.cathy.nls.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.cathy.platform.nls.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.hebe.nls.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.graphicsio.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.share.evernote.nls.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.ui.iconfinder.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.cathy.product&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.share.evernote.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.ui.iconfinder.nls.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.meggy.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.help.nls.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.xmind.share.general.feature.feature.group&apos;, version(&apos;3.7.8.201807240049&apos;)]' min='0'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='net.xmind.workbench.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='net.xmind.workbench.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='XMind Online Support'/>
        <property name='org.eclipse.equinox.p2.description' value='XMind Online Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.xmind.cathy.features'/>
        <property name='maven-artifactId' value='net.xmind.workbench.feature'/>
        <property name='maven-version' value='3.7.8-SNAPSHOT'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.json' range='[1.0.0.201510292325,1.0.0.201510292325]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='license.html' url='license.html'>
          XMind 3 is dual licensed under 2 open source licenses:&#xA;the Eclipse Public License v1.0 (EPL),&#xA;which is available at http://www.eclipse.org/legal/epl-v10.html ,&#xA;and the GNU Lesser General Public License v3 (LGPL),&#xA;which is available at http://www.gnu.org/licenses/lgpl.html .
        </license>
      </licenses>
      <copyright>
        Copyright(C) 2006-2015, XMind Ltd. and others.
      </copyright>
    </unit>
    <unit id='net.xmind.workbench.nls.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='net.xmind.workbench.nls.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='XMind Online Support Native Language Support'/>
        <property name='org.eclipse.equinox.p2.description' value='XMind Online Support Native Language Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.nls.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='53'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.workbench.nls.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='org.xmind.cathy.nls.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.cathy.nls.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='XMind RCP Application Native Language Support'/>
        <property name='org.eclipse.equinox.p2.description' value='XMind RCP Application Native Language Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.nls.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='79'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.win32.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.win32.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.win32.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.win32.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.win32.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.win32.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.win32.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.win32.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.win32.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.win32.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.win32.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.win32.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.win32.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.fonts.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.fonts.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.fonts.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.fonts.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.fonts.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.fonts.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.fonts.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.fonts.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.fonts.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.fonts.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.fonts.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.fonts.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.fonts.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.nls.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='org.xmind.cathy.platform.nls.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.cathy.platform.nls.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='XMind Product Runtime Platform Native Language Support'/>
        <property name='org.eclipse.equinox.p2.description' value='XMind Product Runtime Platform Native Language Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.platform.nls.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='959'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86_64.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86_64.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86_64.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86_64.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86_64.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86_64.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86_64.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86_64.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86_64.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86_64.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86_64.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86_64.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.nl_sl' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.nl_sl' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.nl_sl' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.nl_sl' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cocoa.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cocoa.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cocoa.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cocoa.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cocoa.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cocoa.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cocoa.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cocoa.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cocoa.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cocoa.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cocoa.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cocoa.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms.nl_sl' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net.nl_sl' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.nl_sl' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.cocoa.nl_sl' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.cocoa.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.cocoa.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.cocoa.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.cocoa.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.cocoa.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.cocoa.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.cocoa.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.cocoa.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.cocoa.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.cocoa.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.cocoa.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.cocoa.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'>
          <filter>
            (osgi.ws=cocoa)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state.nl_sl' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.themes.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.themes.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.themes.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.themes.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.themes.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.themes.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.themes.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.themes.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.themes.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.themes.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.themes.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.themes.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.nl_sl' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath.nl_da' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath.nl_pt_BR' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath.nl_ja' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath.nl_it' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath.nl_zh_TW' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath.nl_ru' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath.nl_zh' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath.nl_ar' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath.nl_de' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath.nl_ko' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath.nl_fr' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath.nl_es' range='[4.5.0.v20150804081228,4.5.0.v20150804081228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.platform.nls.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='org.xmind.cathy.product' version='3.7.8.201807240049'>
      <update id='org.xmind.cathy.product' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='XMind'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.product' version='3.7.8.201807240049'/>
      </provides>
      <requires size='10'>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='config.a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.xmind.cathy.product.application' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.xmind.cathy.product.configuration' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.feature.feature.group' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.hebe.feature.feature.group' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.platform.feature.feature.group' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
    </unit>
    <unit id='org.xmind.cathy.product.executable.win32.win32.x86' version='3.7.8.201807240049'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.cathy.product.executable.win32.win32.x86' version='3.7.8.201807240049'/>
        <provided namespace='toolingorg.xmind.cathy.product' name='org.xmind.cathy.product.executable' version='3.7.8.201807240049'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.xmind.cathy.product.executable.win32.win32.x86' version='3.7.8.201807240049'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='org.xmind.graphicsio.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.graphicsio.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='Graphics IO Libraries'/>
        <property name='org.eclipse.equinox.p2.description' value='Graphics IO Libraries'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.xmind.cathy.features'/>
        <property name='maven-artifactId' value='org.xmind.graphicsio.feature'/>
        <property name='maven-version' value='3.7.8-SNAPSHOT'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.graphicsio.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='5'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.de.erichseifert.vectorgraphics2d' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.org.freehep.vectorgraphics' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector.svg' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.graphicsio.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='license.html' url='license.html'>
          XMind 3 is dual licensed under 2 open source licenses:&#xA;the Eclipse Public License v1.0 (EPL),&#xA;which is available at http://www.eclipse.org/legal/epl-v10.html ,&#xA;and the GNU Lesser General Public License v3 (LGPL),&#xA;which is available at http://www.gnu.org/licenses/lgpl.html .
        </license>
      </licenses>
      <copyright>
        Copyright(C) 2006-2015, XMind Ltd. and others.
      </copyright>
    </unit>
    <unit id='org.xmind.hebe.nls.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.hebe.nls.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='XMind Map Editor Native Language Support'/>
        <property name='org.eclipse.equinox.p2.description' value='XMind Map Editor Native Language Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.hebe.nls.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='209'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.runtime.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.runtime.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.runtime.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.runtime.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.runtime.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.runtime.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.runtime.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.runtime.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.runtime.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.runtime.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.runtime.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.runtime.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.runtime.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.ui.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.ui.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.ui.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.ui.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.ui.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.ui.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.ui.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.ui.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.ui.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.ui.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.ui.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.ui.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.gef.ui.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.neuquant.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.neuquant.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.neuquant.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.neuquant.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.neuquant.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.neuquant.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.neuquant.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.neuquant.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.neuquant.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.neuquant.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.neuquant.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.neuquant.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.neuquant.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.fishbone.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.fishbone.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.fishbone.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.fishbone.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.fishbone.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.fishbone.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.fishbone.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.fishbone.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.fishbone.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.fishbone.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.fishbone.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.fishbone.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.fishbone.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spreadsheet.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spreadsheet.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spreadsheet.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spreadsheet.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spreadsheet.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spreadsheet.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spreadsheet.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spreadsheet.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spreadsheet.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spreadsheet.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spreadsheet.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spreadsheet.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spreadsheet.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.toolkit.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.toolkit.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.toolkit.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.toolkit.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.toolkit.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.toolkit.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.toolkit.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.toolkit.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.toolkit.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.toolkit.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.toolkit.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.toolkit.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.toolkit.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.resources.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.resources.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.resources.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.resources.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.resources.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.resources.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.resources.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.resources.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.resources.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.resources.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.resources.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.resources.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.resources.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.browser.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.browser.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.browser.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.browser.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.browser.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.browser.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.browser.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.browser.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.browser.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.browser.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.browser.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.browser.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.browser.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.io.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.io.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.io.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.io.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.io.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.io.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.io.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.io.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.io.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.io.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.io.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.io.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.io.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.imports.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.imports.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.imports.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.imports.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.imports.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.imports.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.imports.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.imports.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.imports.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.imports.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.imports.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.imports.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.imports.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spelling.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spelling.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spelling.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spelling.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spelling.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spelling.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spelling.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spelling.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spelling.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spelling.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spelling.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spelling.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.spelling.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.hebe.nls.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='org.xmind.help.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.help.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='XMind Offline Help Contents'/>
        <property name='org.eclipse.equinox.p2.description' value='XMind Offline Help Contents'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.xmind.help.features'/>
        <property name='maven-artifactId' value='org.xmind.help.feature'/>
        <property name='maven-version' value='3.7.8-SNAPSHOT'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.help.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='2'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.help' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.help.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='license.html' url='license.html'>
          XMind 3 is dual licensed under 2 open source licenses:&#xA;the Eclipse Public License v1.0 (EPL),&#xA;which is available at http://www.eclipse.org/legal/epl-v10.html ,&#xA;and the GNU Lesser General Public License v3 (LGPL),&#xA;which is available at http://www.gnu.org/licenses/lgpl.html .
        </license>
      </licenses>
      <copyright>
        Copyright(C) 2006-2012, XMind Ltd. and others.
      </copyright>
    </unit>
    <unit id='org.xmind.help.nls.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.help.nls.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='XMind Offline Help Contents NLS Support'/>
        <property name='org.eclipse.equinox.p2.description' value='XMind Offline Help Contents NLS Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.xmind.help.features'/>
        <property name='maven-artifactId' value='org.xmind.help.nls.feature'/>
        <property name='maven-version' value='3.7.8-SNAPSHOT'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.help.nls.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='14'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.help.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.help.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.help.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.help.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.help.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.help.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.help.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.help.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.help.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.help.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.help.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.help.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.help.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.help.nls.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='license.html' url='license.html'>
          XMind 3 is dual licensed under 2 open source licenses:&#xA;the Eclipse Public License v1.0 (EPL),&#xA;which is available at http://www.eclipse.org/legal/epl-v10.html ,&#xA;and the GNU Lesser General Public License v3 (LGPL),&#xA;which is available at http://www.gnu.org/licenses/lgpl.html .
        </license>
      </licenses>
      <copyright>
        Copyright(C) 2006-2012, XMind Ltd. and others.
      </copyright>
    </unit>
    <unit id='org.xmind.meggy.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.meggy.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='XMind Pro'/>
        <property name='org.eclipse.equinox.p2.description' value='XMind Pro'/>
        <property name='org.eclipse.equinox.p2.description.url' value='https://www.xmind.net/'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.xmind.meggy.features'/>
        <property name='maven-artifactId' value='org.xmind.meggy.feature'/>
        <property name='maven-version' value='3.7.8-SNAPSHOT'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='31'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.graphicsio.feature.feature.group' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.audionotes' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mapshot' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.merging' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.presentation' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.taskinfo' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.filtering' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.search' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.resources' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.win32' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.verify' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.macosx' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.tools.zip' range='[1.9.6,1.9.6]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.brainstorm' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.mp3player' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javazoom.jlayer' range='[1.0.1,1.0.1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.styleeditor' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.aspose' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector.pdf' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.outline' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.ideafactory' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.pro' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.index' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.xmindresource' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.exports.vector' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='https://www.xmind.net/license/xpla/' url='https://www.xmind.net/license/xpla/'>
          XMIND PRO SOFTWARE LICENSE AGREEMENT&#xA;&#xA;Nov 6, 2008&#xA;&#xA;XMIND, LTD. (&quot;LICENSOR&quot;) LICENSES THE ATTACHED SOFTWARE TO YOU (&quot;LICENSEE&quot;)&#xA;ONLY UPON THE CONDITION THAT YOU ACCEPT ALL OF THE TERMS IN THIS LICENSE&#xA;AGREEMENT (THE &quot;LICENSE&quot;). IF YOU DO NOT AGREE TO THE TERMS OF THIS LICENSE&#xA;AGREEMENT, DO NOT INSTALL, COPY OR USE THE SOFTWARE.&#xA;&#xA;License Terms&#xA;&#xA;The software that accompanies this License, including the clip art, images,&#xA;templates and samples (collectively, the &quot;Software&quot;), is the property of&#xA;Licensor or its licensors, and is protected by copyright and other&#xA;intellectual property law.&#xA;&#xA;1) Licensor grants Licensee the non-exclusive, non-transferable right and&#xA;license to install and use the Software in accordance with the then-current&#xA;XMind registration, download and subscription terms specified on the XMind&#xA;website at www.xmind.net/www.xmind.org, and the terms of this License.&#xA;&#xA;2) Licensee may use the clip art, images, templates and samples in the&#xA;Software only in combination with the Software.&#xA;&#xA;3) Licensee may permit the Software to be accessed through Licensee&apos;s&#xA;internal electronic network provided that each person accessing the&#xA;Software through the network must have a corresponding paid subscription&#xA;designated for that person.&#xA;&#xA;4) Licensee may not rent, lease, copy, distribute, license, assign or&#xA;otherwise transfer the Software to any other party.&#xA;&#xA;5) Licensee may not reverse engineer, decompile, or disassemble the&#xA;Software.&#xA;&#xA;6) Licensor warrants that the Software will perform substantially as&#xA;described in its documentation for a period of sixty (60) days from&#xA;purchase of a subscription. Licensor does not warrant that operation&#xA;of the Software will be uninterrupted or that the Software will be&#xA;error-free.&#xA;&#xA;Licensee&apos;s sole remedy under the Software warranty is for Licensor, at&#xA;Licensor&apos;s option, to either: a) repair or replace the Software that&#xA;does not meet the foregoing warranty if a timely claim is made within&#xA;the warranty period, or b) issue a full refund of the subscription price&#xA;paid.&#xA;&#xA;To the extent permitted by applicable law, the foregoing limited&#xA;warranty is in lieu of all other warranties or conditions, express or&#xA;implied, and Licensor disclaims any and all implied warranties or&#xA;conditions, including any implied warranty of title, non-infringement,&#xA;merchantability or fitness for a particular purpose, regardless of whether&#xA;Licensor knows or has reason to know of Licensee&apos;s particular needs.&#xA;&#xA;7) In no event will Licensor be liable to Licensee for any damages&#xA;connected with or resulting from this License or Licensee&apos;s use of the&#xA;Software.&#xA;&#xA;8) Licensee agrees to defend and indemnify Licensor, and hold Licensor&#xA;harmless from and against any and all claims which a third party may&#xA;assert against Licensor by reason of or as a consequence of Licensee&apos;s&#xA;use of the Software.&#xA;&#xA;9) Licensor has the right to terminate this License and Licensee&apos;s right&#xA;to use the Software upon any material breach by Licensee.&#xA;&#xA;10) This License is the entire and exclusive agreement between Licensor&#xA;and Licensee regarding this Software. This License agreement replaces and&#xA;supersedes all prior negotiations, dealings, and agreements between&#xA;Licensor and Licensee regarding this Software.
        </license>
      </licenses>
      <copyright>
        Copyright(C) 2006-2012, XMind Ltd. All rights reserved.
      </copyright>
    </unit>
    <unit id='org.xmind.meggy.nls.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.meggy.nls.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='XMind Pro Native Language Support'/>
        <property name='org.eclipse.equinox.p2.description' value='XMind Pro Native Language Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.nls.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='352'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.audionotes.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.audionotes.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.audionotes.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.audionotes.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.audionotes.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.audionotes.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.audionotes.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.audionotes.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.audionotes.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.audionotes.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.audionotes.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.audionotes.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.audionotes.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mapshot.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mapshot.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mapshot.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mapshot.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mapshot.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mapshot.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mapshot.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mapshot.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mapshot.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mapshot.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mapshot.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mapshot.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mapshot.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.merging.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.merging.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.merging.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.merging.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.merging.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.merging.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.merging.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.merging.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.merging.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.merging.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.merging.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.merging.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.merging.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.presentation.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.presentation.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.presentation.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.presentation.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.presentation.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.presentation.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.presentation.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.presentation.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.presentation.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.presentation.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.presentation.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.presentation.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.presentation.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.taskinfo.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.taskinfo.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.taskinfo.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.taskinfo.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.taskinfo.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.taskinfo.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.taskinfo.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.taskinfo.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.taskinfo.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.taskinfo.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.taskinfo.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.taskinfo.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.taskinfo.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.filtering.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.filtering.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.filtering.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.filtering.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.filtering.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.filtering.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.filtering.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.filtering.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.filtering.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.filtering.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.filtering.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.filtering.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.filtering.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.search.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.search.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.search.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.search.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.search.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.search.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.search.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.search.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.search.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.search.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.search.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.search.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.search.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.resources.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.resources.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.resources.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.resources.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.resources.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.resources.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.resources.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.resources.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.resources.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.resources.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.resources.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.resources.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gallery.resources.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.win32.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.win32.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.win32.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.win32.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.win32.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.win32.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.win32.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.win32.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.win32.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.win32.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.win32.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.win32.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.win32.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.verify.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.verify.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.verify.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.verify.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.verify.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.verify.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.verify.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.verify.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.verify.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.verify.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.verify.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.verify.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.verify.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.macosx.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.macosx.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.macosx.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.macosx.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.macosx.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.macosx.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.macosx.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.macosx.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.macosx.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.macosx.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.macosx.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.macosx.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.lame.macosx.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.brainstorm.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.brainstorm.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.brainstorm.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.brainstorm.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.brainstorm.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.brainstorm.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.brainstorm.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.brainstorm.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.brainstorm.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.brainstorm.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.brainstorm.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.brainstorm.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.brainstorm.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.mp3player.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.mp3player.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.mp3player.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.mp3player.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.mp3player.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.mp3player.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.mp3player.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.mp3player.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.mp3player.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.mp3player.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.mp3player.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.mp3player.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.audio.mp3player.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.styleeditor.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.styleeditor.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.styleeditor.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.styleeditor.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.styleeditor.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.styleeditor.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.styleeditor.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.styleeditor.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.styleeditor.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.styleeditor.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.styleeditor.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.styleeditor.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.mindmap.styleeditor.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.aspose.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.aspose.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.aspose.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.aspose.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.aspose.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.aspose.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.aspose.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.aspose.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.aspose.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.aspose.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.aspose.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.aspose.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.aspose.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector.pdf.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector.pdf.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector.pdf.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector.pdf.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector.pdf.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector.pdf.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector.pdf.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector.pdf.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector.pdf.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector.pdf.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector.pdf.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector.pdf.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.vector.pdf.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.outline.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.outline.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.outline.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.outline.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.outline.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.outline.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.outline.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.outline.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.outline.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.outline.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.outline.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.outline.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.exports.outline.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.ideafactory.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.ideafactory.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.ideafactory.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.ideafactory.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.ideafactory.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.ideafactory.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.ideafactory.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.ideafactory.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.ideafactory.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.ideafactory.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.ideafactory.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.ideafactory.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.ideafactory.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.pro.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.pro.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.pro.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.pro.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.pro.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.pro.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.pro.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.pro.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.pro.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.pro.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.pro.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.pro.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.menus.pro.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.index.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.index.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.index.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.index.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.index.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.index.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.index.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.index.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.index.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.index.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.index.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.index.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.index.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.xmindresource.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.xmindresource.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.xmindresource.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.xmindresource.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.xmindresource.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.xmindresource.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.xmindresource.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.xmindresource.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.xmindresource.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.xmindresource.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.xmindresource.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.xmindresource.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.xmindresource.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.exports.vector.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.exports.vector.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.exports.vector.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.exports.vector.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.exports.vector.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.exports.vector.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.exports.vector.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.exports.vector.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.exports.vector.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.exports.vector.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.exports.vector.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.exports.vector.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.gantt.exports.vector.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.meggy.nls.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='org.xmind.share.biggerplate.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.share.biggerplate.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='Sharing Support For Biggerplate'/>
        <property name='org.eclipse.equinox.p2.description' value='Sharing Support For Biggerplate'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.xmind.cathy.features'/>
        <property name='maven-artifactId' value='org.xmind.share.biggerplate.feature'/>
        <property name='maven-version' value='3.7.8-SNAPSHOT'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.biggerplate.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='4'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.json' range='[1.0.0.201510292325,1.0.0.201510292325]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.biggerplate' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.biggerplate.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='license.html' url='license.html'>
          XMind 3 is dual licensed under 2 open source licenses:&#xA;the Eclipse Public License v1.0 (EPL),&#xA;which is available at http://www.eclipse.org/legal/epl-v10.html ,&#xA;and the GNU Lesser General Public License v3 (LGPL),&#xA;which is available at http://www.gnu.org/licenses/lgpl.html .
        </license>
      </licenses>
      <copyright>
        Copyright(C) 2006-2015, XMind Ltd. and others.
      </copyright>
    </unit>
    <unit id='org.xmind.share.biggerplate.nls.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.share.biggerplate.nls.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Sharing Support For Biggerplate Native Language Support'/>
        <property name='org.eclipse.equinox.p2.description' value='Sharing Support For Biggerplate Native Language Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.biggerplate.nls.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='27'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.biggerplate.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.biggerplate.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.biggerplate.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.biggerplate.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.biggerplate.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.biggerplate.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.biggerplate.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.biggerplate.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.biggerplate.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.biggerplate.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.biggerplate.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.biggerplate.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.biggerplate.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.biggerplate.nls.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='org.xmind.share.evernote.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.share.evernote.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='Sharing Support For Evernote'/>
        <property name='org.eclipse.equinox.p2.description' value='Sharing Support For Evernote'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.xmind.cathy.features'/>
        <property name='maven-artifactId' value='org.xmind.share.evernote.feature'/>
        <property name='maven-version' value='3.7.8-SNAPSHOT'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.evernote.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='4'>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.evernote.sdk.java' range='[1.25.1,1.25.1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.scribe.oauth' range='[1.3.6.201601271330,1.3.6.201601271330]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.evernote' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.evernote.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='license.html' url='license.html'>
          XMind 3 is dual licensed under 2 open source licenses:&#xA;the Eclipse Public License v1.0 (EPL),&#xA;which is available at http://www.eclipse.org/legal/epl-v10.html ,&#xA;and the GNU Lesser General Public License v3 (LGPL),&#xA;which is available at http://www.gnu.org/licenses/lgpl.html .
        </license>
      </licenses>
      <copyright>
        Copyright(C) 2006-2015, XMind Ltd. and others.
      </copyright>
    </unit>
    <unit id='org.xmind.share.evernote.nls.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.share.evernote.nls.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Sharing Support For Evernote Native Language Support'/>
        <property name='org.eclipse.equinox.p2.description' value='Sharing Support For Evernote Native Language Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.evernote.nls.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='14'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.evernote.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.evernote.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.evernote.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.evernote.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.evernote.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.evernote.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.evernote.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.evernote.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.evernote.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.evernote.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.evernote.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.evernote.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.evernote.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.evernote.nls.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='org.xmind.share.general.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.share.general.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='Sharing Support'/>
        <property name='org.eclipse.equinox.p2.description' value='Sharing Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.xmind.cathy.features'/>
        <property name='maven-artifactId' value='org.xmind.share.general.feature'/>
        <property name='maven-version' value='3.7.8-SNAPSHOT'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='7'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.json' range='[1.0.0.201510292325,1.0.0.201510292325]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.share' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='license.html' url='license.html'>
          XMind 3 is dual licensed under 2 open source licenses:&#xA;the Eclipse Public License v1.0 (EPL),&#xA;which is available at http://www.eclipse.org/legal/epl-v10.html ,&#xA;and the GNU Lesser General Public License v3 (LGPL),&#xA;which is available at http://www.gnu.org/licenses/lgpl.html .
        </license>
      </licenses>
      <copyright>
        Copyright(C) 2006-2015, XMind Ltd. and others.
      </copyright>
    </unit>
    <unit id='org.xmind.share.general.nls.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.share.general.nls.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Sharing Support Native Language Support'/>
        <property name='org.eclipse.equinox.p2.description' value='Sharing Support Native Language Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.nls.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='66'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.net.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.core.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.signin.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.share.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.share.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.share.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.share.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.share.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.share.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.share.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.share.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.share.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.share.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.share.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.share.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.xmind.share.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.general.nls.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='org.xmind.share.localnetwork.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.share.localnetwork.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='Sharing Support For Local Network'/>
        <property name='org.eclipse.equinox.p2.description' value='Sharing Support For Local Network'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.xmind.cathy.features'/>
        <property name='maven-artifactId' value='org.xmind.share.localnetwork.feature'/>
        <property name='maven-version' value='3.7.8-SNAPSHOT'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.localnetwork.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='8'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.sharing.localnetwork' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.coobird.thumbnailator' range='[0.4.8,0.4.8]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.apple.dnssd' range='[561.1.1.201511271140,561.1.1.201511271140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.lan' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.localnetwork.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='license.html' url='license.html'>
          XMind 3 is dual licensed under 2 open source licenses:&#xA;the Eclipse Public License v1.0 (EPL),&#xA;which is available at http://www.eclipse.org/legal/epl-v10.html ,&#xA;and the GNU Lesser General Public License v3 (LGPL),&#xA;which is available at http://www.gnu.org/licenses/lgpl.html .
        </license>
      </licenses>
      <copyright>
        Copyright(C) 2006-2015, XMind Ltd. and others.
      </copyright>
    </unit>
    <unit id='org.xmind.share.localnetwork.nls.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.share.localnetwork.nls.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Sharing Support For Local Network Native Language Support'/>
        <property name='org.eclipse.equinox.p2.description' value='Sharing Support For Local Network Native Language Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.localnetwork.nls.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='66'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.sharing.localnetwork.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.sharing.localnetwork.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.sharing.localnetwork.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.sharing.localnetwork.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.sharing.localnetwork.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.sharing.localnetwork.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.sharing.localnetwork.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.sharing.localnetwork.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.sharing.localnetwork.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.sharing.localnetwork.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.sharing.localnetwork.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.sharing.localnetwork.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.sharing.localnetwork.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.sharing.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (|(osgi.os=macosx)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.lan.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.lan.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.lan.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.lan.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.lan.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.lan.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.lan.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.lan.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.lan.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.lan.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.lan.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.lan.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.core.command.remote.lan.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.share.localnetwork.nls.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='org.xmind.ui.iconfinder.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.ui.iconfinder.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='Iconfinder'/>
        <property name='org.eclipse.equinox.p2.description' value='Iconfinder'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.xmind.meggy.features'/>
        <property name='maven-artifactId' value='org.xmind.ui.iconfinder.feature'/>
        <property name='maven-version' value='3.7.8-SNAPSHOT'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='2'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='license.html' url='license.html'>
          XMind 3 is dual licensed under 2 open source licenses:&#xA;the Eclipse Public License v1.0 (EPL),&#xA;which is available at http://www.eclipse.org/legal/epl-v10.html ,&#xA;and the GNU Lesser General Public License v3 (LGPL),&#xA;which is available at http://www.gnu.org/licenses/lgpl.html .
        </license>
      </licenses>
      <copyright>
        Copyright(C) 2006-2015, XMind Ltd. and others.
      </copyright>
    </unit>
    <unit id='org.xmind.ui.iconfinder.nls.feature.feature.group' version='3.7.8.201807240049' singleton='false'>
      <update id='org.xmind.ui.iconfinder.nls.feature.feature.group' range='[0.0.0,3.7.8.201807240049)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Iconfinder Native Language Support'/>
        <property name='org.eclipse.equinox.p2.description' value='Iconfinder Native Language Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='XMind Ltd.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.nls.feature.feature.group' version='3.7.8.201807240049'/>
      </provides>
      <requires size='14'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.nl_sl' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.nl_da' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.nl_pt_BR' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.nl_ja' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.nl_it' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.nl_zh_TW' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.nl_ru' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.nl_zh_CN' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.nl_ar' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.nl_de' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.nl_ko' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.nl_fr' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.nl_es' range='[3.7.8.201807240049,3.7.8.201807240049]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.xmind.ui.iconfinder.nls.feature.feature.jar' range='[3.7.8.201807240049,3.7.8.201807240049]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
  </units>
  <iusProperties size='23'>
    <iuProperties id='SharedProfile_XMindProfile' version='1.0.0.1545818442177'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='net.xmind.workbench.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='net.xmind.workbench.nls.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.cathy.nls.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.cathy.platform.nls.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.cathy.product' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.cathy.product.executable.win32.win32.x86' version='3.7.8.201807240049'>
      <properties size='3'>
        <property name='unzipped|@artifact|/opt/xmind-build/workspace/temp/bundle/cathy_win32/src/XMind 8 Update 8' value='/opt/xmind-build/workspace/temp/bundle/cathy_win32/src/XMind 8 Update 8/eclipsec.exe|/opt/xmind-build/workspace/temp/bundle/cathy_win32/src/XMind 8 Update 8/XMind.exe|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.graphicsio.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.hebe.nls.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.help.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.help.nls.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.meggy.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.meggy.nls.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.share.biggerplate.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.share.biggerplate.nls.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.share.evernote.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.share.evernote.nls.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.share.general.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.share.general.nls.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.share.localnetwork.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.share.localnetwork.nls.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.ui.iconfinder.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.xmind.ui.iconfinder.nls.feature.feature.group' version='3.7.8.201807240049'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
